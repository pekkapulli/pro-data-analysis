#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
PORT=4173
URL="http://localhost:$PORT"
if command -v open >/dev/null 2>&1; then
	open "$URL"
elif command -v xdg-open >/dev/null 2>&1; then
	xdg-open "$URL"
fi
python3 -m http.server "$PORT"

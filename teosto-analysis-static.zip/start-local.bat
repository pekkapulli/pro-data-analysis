@echo off
set PORT=4173
start http://localhost:%PORT%
py -m http.server %PORT%
